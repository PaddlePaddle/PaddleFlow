#!/usr/bin/env python3 

""" mock paddleflow.pipeline.dsl.steps.Step
"""

class Step(object):
    """ mock paddleflow.pipeline.dsl.steps.Step
    """
    def __init__(self, name):
        """ init
        """
        self.name = name
        self.full_name = name
