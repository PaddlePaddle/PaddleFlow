# paddleflow镜像构建指南
构建镜像包含:
- paddleflow-server
- paddleflow-csi-plugin

```shell
# 构建镜像
bash ./build_latest.sh
```